//Slider main
$(document).ready(function() {

  $('.outer_slider').owlCarousel({

    margin: 0,
    dots: true,
    nav: true,

    responsive: {
      0: {
        items: 1,
        nav: true,
        loop: false
      },
      600: {
        items: 1,
        nav: false
      },
      1000: {
        items: 1,
        nav: true,
        loop: false,
        dots: true
      }
    }
  });
  $('.header_slider').owlCarousel({

    margin: 0,
    dots: true,
    nav: true,

    responsive: {
      0: {
        items: 1,
        nav: true,
        loop: false
      },
      600: {
        items: 1,
        nav: false
      },
      1000: {
        items: 1,
        nav: true,
        loop: false,
        dots: true
      }
    }
  });

  /* code jquery show/off the back window mobile */
  $('.navbar-toggle').click(function() {

    if ($('.background-body').hasClass('non-active')) {
      $('.background-body').removeClass('non-active');
    }
    else {
      $('.background-body').addClass('non-active');

    }
  });
  /* end code jquery show/off */
  $('.out_list_FAQ').click(function() {
    $(this).children('.list_tn').slideToggle();
  });
});
